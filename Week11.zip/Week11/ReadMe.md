What I want for this assignment beyond the miniums requirements
-Change The squares to be chosen images [ ]
-background to be creative [ Check]
-The whole thing to have a pixelated look [ ]
-Add sound to collison [ ]