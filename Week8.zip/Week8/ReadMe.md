3/7/2022 - This looks like its going to be fun! A little overwhelming, but fun. I hope to create a silhouette piece of Alice and the cheshire cat in the tree. However, I do have a couple other ideas if that is too complex. 

To Do: 
Find Images
Jot down $ tags to help me move images/texts
Make Button 
Animate background-shapes? 
Look for Font

3/8/2022 

Need to 
-Make Alice appear at first click : Check
-Change scene at second click : 
    - Imagery will change 
    - color will change 
-Words will appear at third click : 