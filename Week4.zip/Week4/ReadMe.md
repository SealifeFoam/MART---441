I am so glad comments exist because I wouldn't be organized if there wasn't.

The main problems I find that I am facing are simple fix and small programing errors I made. Thankfully, I got help. 
However, most tidious thing about this assignment isn't the js itself but the story and questions you have to make up for each choice. 